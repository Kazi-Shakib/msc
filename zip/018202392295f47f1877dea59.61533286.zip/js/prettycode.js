!function ($) {

  $(function(){

    var $window = $(window)


    // make code pretty
    window.prettyPrint && prettyPrint()

  })


}(window.jQuery)